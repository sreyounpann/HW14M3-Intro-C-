//
//  main.cpp
//  Exercise3(1)
//
//  Created by MacBook air on 6/3/22.
//

#include <iostream>
using namespace std;
int main(){

    cout << "\n     Exercise 3\n\n";
    float a, s, v, t;

    cout << "Enter Speed of V:\n" ;
    cin >> v;

    cout << "Enter time:\n";
    cin >> t;

    cout << "Enter accelration:\n";
    cin >> a;

    s = v * t +(a *t*t)/2;
    cout << "Traveled Distance = " << s << endl;

}
