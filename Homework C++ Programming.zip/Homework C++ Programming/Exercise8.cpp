//
//  main.cpp
//  Exercise8
//
//  Created by MacBook air on 6/3/22.
//

#include <iostream>
using namespace std;
int main(){
    cout << "\t\tExercise8\n";
    int weeks, day2, day;
    cout << "Enter total number of days :";
    cin >> day;
    
    weeks = day/7;
    day2 = day % 7;
    
    cout << weeks << " Weeks , "  << day2 << " day." << endl;
    return 0;
    
    
}
