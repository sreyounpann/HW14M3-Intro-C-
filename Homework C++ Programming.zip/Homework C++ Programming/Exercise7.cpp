//
//  main.cpp
//  Exercise7
//
//  Created by MacBook air on 6/3/22.
//

#include <iostream>
using namespace std;
int main(){
    cout << "\t\tExercise7\n";
    
    float minute, Price;
    cout << " Cost of call per minute: ";
    cin >> Price; //3
    
    cout << " Insert duration of call :";
    cin >> minute; //1.10
    
    int min = minute; //1
    float second = minute - min; //0.10
    float second1 = second * 100; //10
    
    float totalsec = second1/60; //0,166666666666667
    float totalsec1 = totalsec * Price; //0.5
    float callprice = (min * Price) + totalsec1; // 1*3+0.5= 3.5$
    cout << " Cost of call : "  "$"<< callprice << endl;
}
