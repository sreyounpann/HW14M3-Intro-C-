//
//  main.cpp
//  Homework3
//
//  Created by MacBook air on 3/3/22.
//

#include <iostream>
using namespace std;
int main()
{
    cout << "\n     Exercise 1\n\n";

       float R0, R1, R2, R3;
       cout << "Enter R1 :\n";
       cin >> R1;

       cout << "Enter R2 :\n";
       cin >> R2;

       cout << "Enter R3 :\n";
       cin >> R3;

       R0 = 1 / (1 / R1 + 1 / R2 + 1 / R3);

       cout << "Resistance value R0 = " << R0 << "\n";
    return 0;
}

