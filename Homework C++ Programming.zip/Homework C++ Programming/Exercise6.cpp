//
//  main.cpp
//  Exercise6
//
//  Created by MacBook air on 6/3/22.

#include<iostream>
#include<iomanip>
using namespace std;
int main(){
    
    cout << "\tExercise 6\n";
int  L,m,fi;

double t,s,f,speed;
cout<<"Input a distance length:  ";
cin>>L;
cout<<"Input a time           :  ";
cin>>t;
m=t;
f=t-m;
fi=f*100;
s=(m*60)+fi;
speed=L/s*3.6;
cout<<"F                      :  "<<f<<endl;
cout<<"Distance               :  "<<L<<" m\n";
cout<<"Time                   :  "<<m<<" minutes "<<fi<<" seconds "<<" = "<<s<<" seconds\n";
cout<<"You ran at a speed     :  ";
cout<<fixed<<setprecision (2) <<speed<<"km/h"<<endl;
}
