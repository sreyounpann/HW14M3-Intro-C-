//
//  main.cpp
//  Exercise 2

//  Created by MacBook air on 3/3/22.

#include <iostream>
using namespace std;
int main(){
    cout << "\n     Exercise 2\n\n";
    float pi, r, s, l;
    pi = 3.14;
    cout << " Enter Length of Circle = ";
    cin >> l;
    r = l / 2 * pi;
    s = pi * (r*r);
    cout << " Area of Circle  = " << s <<endl;
}
