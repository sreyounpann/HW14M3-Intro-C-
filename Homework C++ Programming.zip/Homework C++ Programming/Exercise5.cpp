
//  main.cpp
//  Exercise5
//
//  Created by MacBook air on 3/3/22.

#include <iostream>
using namespace std;
int main(){
    cout <<"\tExercise5\n";
    
    float N;
    cout << " Input money: ";
    cin >> N;
    
    int P = N;
    float F = N - P;
    int Fi = F * 100;
    
    cout << P << " Dollars ";
    cout << Fi <<" Cents"<< endl;
}
