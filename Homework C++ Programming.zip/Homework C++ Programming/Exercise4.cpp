//
//  main.cpp
//  Exercise4
//
//  Created by MacBook air on 3/3/22.

#include <iostream>
using namespace std;
int main(){
    cout << "\n     Exercise 4\n\n";
    int hour, min, second;
    cout << "Insert the Amount of Second :";
    cin >> second;
    
    min = second / 60;
    second = second % 60;
    hour = min / 60;
    min = min % 60;
    
    cout << "result =  "<< hour<< "hour "<< min <<"minute "<<second<<"second "<< endl;
}
